package lab9;
import java.util.*;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Restaurant r=new Restaurant();
		Customer c[]=new Customer[2];
		Menu m=new Menu("Idly","Paratha","Tea",100.0,70.0,10.0);
		for(int i=0;i<2;i++) {
			System.out.println("\n1.RegularCustomer\n2.Nonregular Customer");
			int ch=sc.nextInt();
			System.out.print("Enter address:");
			String a=sc.next();
			Address ad=new Address(a);
			if(ch==1) {
				c[i]=new RegularCustomer(m,ad);
				
			}
			else
			{
				c[i]=new NonregularCustomer(m,ad);
			}
			r.registerCustomer(c[i]);
			boolean order=true;
			
			
			while(order==true) {
				System.out.println("1.Add item in order\n2.Order over");
				ch=sc.nextInt();
				switch(ch) {
				case 1:
					m.display();
					int choice=sc.nextInt();
					if(choice==1) {
						Order o=new Order(m.item1,m.price1);
						c[i].placeOrder(o);
					}
					else if(choice==2) {
						Order o=new Order(m.item2,m.price2);
						c[i].placeOrder(o);
					}
					else
					{
						Order o=new Order(m.item3,m.price3);
						c[i].placeOrder(o);
					}
					break;
				case 2:
					c[i].completeOrder(r);
					order=false;
					break;
				}
			}
			System.out.println("Total Bill:"+c[i].calculateBill());
		}
		sc.close();
	}

}
