package lab9;
import java.util.*;
public class Restaurant {
	ArrayList<Customer> cus=new ArrayList<Customer>();
	ArrayList<ArrayList<Order>> ord=new ArrayList<ArrayList<Order>>();
	
	public void registerCustomer(Customer c) {
		cus.add(c);
	}
	public void addOrder(ArrayList<Order> o) {
		ord.add(o);
	}
}


class Order{
	String item1;
	double price;
	public Order(String item1,double price) {
		this.item1=item1;
		this.price=price;
	}
}

class Address{
	String address;
	public Address(String address) {
		this.address=address;
	}
	
}
class Customer{
	Address a;
	Menu m;
	ArrayList<Order> order=new ArrayList<Order>();
	
	public Customer(Menu m,Address a) {
		this.m=m;
		this.a=a;
	}
	
	public void viewMenu() {
		m.display();
	}
	public void placeOrder(Order o) {
		order.add(o);
	}
	public double calculateBill() {
		return 0.0;
	}
	public void completeOrder(Restaurant r) {
		r.addOrder(order);
	}
}
class RegularCustomer extends Customer{
	public RegularCustomer(Menu m,Address a) {
		super(m,a);
	}
	
	public double calculateBill() {
		Iterator<Order> it=order.iterator();
		double sum=0.0;
		while(it.hasNext()) {
			sum+=it.next().price;
		}
		return sum*0.9;
	}
}

class NonregularCustomer extends Customer{
	public NonregularCustomer(Menu m,Address a) {
		super(m,a);
	}
	
	public double calculateBill() {
		Iterator<Order> it=order.iterator();
		double sum=0.0;
		while(it.hasNext()) {
			sum+=it.next().price;
		}
		return sum;
	}
}
class Menu{
	String item1,item2,item3;
	double price1,price2,price3;
	public Menu(String item1,String item2,String item3,double price1,double price2,double price3) {
		this.item1=item1;
		this.item2=item2;
		this.item3=item3;
		this.price1=price1;
		this.price2=price2;
		this.price3=price3;
	}
	
	void display() {
		System.out.println("Menu:\n1."+item1+" "+price1+"\n2."+item2+" "+price2+"\n3."+item3+" "+price3);
	}
}


